# test_send.py
import asyncio
from aiogram import Bot
from config import BOT_TOKEN, REPORT_CHAT_ID

async def main():
    bot = Bot(token=BOT_TOKEN)
    try:
        r = await bot.send_message(REPORT_CHAT_ID, "🧪 Тестовое сообщение для проверки REPORT_CHAT_ID")
        print("OK sent:", r.message_id, "chat:", r.chat.id)
    except Exception as e:
        print("ERROR send:", type(e), e)
    await bot.session.close()

asyncio.run(main())
