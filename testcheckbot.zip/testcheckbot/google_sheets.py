import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

class SheetsClient:
    """
    Google Sheets helper:
    - first column is ID (student_id from local DB)
    - columns:
      1 ID, 2 Имя ребёнка, 3 Филиал, 4 Класс, 5 Язык, 6 Телефон,
      7 Placement test, 8 Группа подтверждена, 9 SMS отправлено,
      10 Проверил, 11 Статус, 12 Время обновления
    """
    def __init__(self, creds_json_path, spreadsheet_id):
        scope = [
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ]
        creds = ServiceAccountCredentials.from_json_keyfile_name(creds_json_path, scope)
        self.gc = gspread.authorize(creds)
        self.sheet = self.gc.open_by_key(spreadsheet_id).sheet1
        print("✅ Подключение к Google Sheets успешно!")

    def prepare_headers_if_empty(self):
        try:
            first_row = self.sheet.row_values(1)
            if not first_row:
                headers = [
                    "ID", "Имя ребёнка", "Филиал", "Класс", "Язык", "Телефон",
                    "Placement test", "Группа подтверждена", "SMS отправлено",
                    "Проверил", "Статус", "Время обновления"
                ]
                self.sheet.append_row(headers)
                print("🟢 Заголовки добавлены в Google Sheet")
        except Exception as e:
            print("⚠️ Не удалось проверить/создать заголовки:", e)

    def append_student(self, sid, name, branch, class_name, language, phone):
        """Добавляет ученика в таблицу — stores sid in first column."""
        for attempt in range(3):  # до 3 попыток
            try:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                row = [
                    str(sid),
                    name or "",
                    branch or "",
                    class_name or "",
                    language or "",
                    phone or "",
                    "🟡",
                    "🟡",
                    "🟡",
                    "-",
                    "Ожидание",
                    now
                ]
                self.sheet.append_row(row)
                print(f"✅ append_student: id={sid} name={name}")
                return
            except Exception as e:
                print(f"⚠️ append_student попытка {attempt+1}: {e}")
                import time
                time.sleep(2)
        print(f"❌ append_student: все попытки неудачны для sid={sid}")


    def find_row_by_id(self, sid):
        """Возвращает номер строки с заданным sid (str) или None"""
        try:
            cell = self.sheet.find(str(sid))
            if cell:
                return cell.row
            return None
        except Exception as e:
            # если не найдено — find бросает исключение, обрабатываем
            return None

    def update_step_by_id(self, sid, step_name, checked_by):
        """
        Обновляет шаг для строки, найденной по sid.
        step_name: 'placement' | 'group' | 'sms'
        """
        col_map = {"placement": 7, "group": 8, "sms": 9}
        if step_name not in col_map:
            print(f"⚠️ Unknown step: {step_name}")
            return
        try:
            row = self.find_row_by_id(sid)
            if not row:
                print(f"⚠️ update_step_by_id: sid {sid} не найден в таблице")
                return
            col = col_map[step_name]
            self.sheet.update_cell(row, col, "✅")
            # записываем кто проверил
            self.sheet.update_cell(row, 10, checked_by or "-")
            # обновляем время
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.sheet.update_cell(row, 12, now)
            print(f"🔄 update_step_by_id: sid={sid} step={step_name} by={checked_by}")
        except Exception as e:
            print(f"⚠️ Ошибка update_step_by_id: {e}")

    def mark_ready_by_id(self, sid):
        """Ставит статус 'Готов' для sid"""
        try:
            row = self.find_row_by_id(sid)
            if not row:
                print(f"⚠️ mark_ready_by_id: sid {sid} не найден")
                return
            self.sheet.update_cell(row, 11, "Готов")
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.sheet.update_cell(row, 12, now)
            print(f"✅ mark_ready_by_id: sid={sid}")
        except Exception as e:
            print(f"⚠️ Ошибка mark_ready_by_id: {e}")
