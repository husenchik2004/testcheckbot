import os
from dotenv import load_dotenv

# =============================
# 🔧 Загрузка переменных окружения
# =============================
load_dotenv()

# =============================
# 🤖 Основные параметры бота
# =============================
BOT_TOKEN = os.getenv("BOT_TOKEN")
SPREADSHEET_ID = os.getenv("SPREADSHEET_ID")
GOOGLE_CREDS_JSON = os.getenv("GOOGLE_CREDS_JSON")
DATABASE_PATH = os.getenv("DATABASE_PATH", "startcheck.db")

# =============================
# 💬 Настройки групп (чаты)
# =============================
# Группа, куда приходят анкеты
SOURCE_CHAT_ID = int(os.getenv("SOURCE_CHAT_ID", "-1002996150074"))  #1001918799252 гр учебки.     #1003033617810gruppa dlya testa 

# Группа, куда бот отправляет готовое сообщение с кнопками
TARGET_CHAT_ID = int(os.getenv("TARGET_CHAT_ID", "-1003033617810"))       #1002996150074

# Чат для ежедневных отчётов
REPORT_CHAT_ID = int(os.getenv("REPORT_CHAT_ID", "-1003033617810"))

# =============================
# 🧩 Проверки на наличие данных
# =============================
missing = []

if not BOT_TOKEN:
    missing.append("BOT_TOKEN")
if not SPREADSHEET_ID:
    missing.append("SPREADSHEET_ID")
if not GOOGLE_CREDS_JSON:
    missing.append("GOOGLE_CREDS_JSON")

if missing:
    raise RuntimeError(f"❌ Не заданы обязательные переменные в .env: {', '.join(missing)}")

# =============================
# ✅ Подтверждение загрузки
# =============================
print("✅ Конфигурация загружена успешно:")
print(f"  ├── BOT_TOKEN: {'OK' if BOT_TOKEN else 'MISSING'}")
print(f"  ├── SOURCE_CHAT_ID: {SOURCE_CHAT_ID}")
print(f"  ├── TARGET_CHAT_ID: {TARGET_CHAT_ID}")
print(f"  ├── REPORT_CHAT_ID: {REPORT_CHAT_ID}")
print(f"  ├── SPREADSHEET_ID: {'OK' if SPREADSHEET_ID else 'MISSING'}")
print(f"  └── GOOGLE_CREDS_JSON: {GOOGLE_CREDS_JSON}")
ADMINS = [1450296021, 420533161]  # Telegram user IDs админов